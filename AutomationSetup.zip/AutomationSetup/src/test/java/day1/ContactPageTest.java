package day1;

import java.time.Duration;
import java.util.Random;
import java.util.UUID;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ContactPageTest {
	
	WebDriver driver;
	
	private String generateUniqueCampaignName() {
	    String uniqueID = UUID.randomUUID().toString().substring(0, 6); // Short unique ID
	    return "User" + "_" + uniqueID;
	}
	
//	private String generateUniqueNum() {
//	    String uniqueID = UUID.randomUUID().toString().substring(0, 10); // Short unique ID
//	    return uniqueID;
//	}
	private String generateUniqueNum() {
        Random random = new Random();
        long number = (long) (random.nextDouble() * 1_000_000_0000L); // Generate a random 10-digit number
        return String.format("%010d", number); // Ensure it’s 10 digits, padding with zeros if necessary
    }
	
	// setup
	@BeforeClass
	void setup() {
		driver=new ChromeDriver();
		driver.get("https://www.app.aisensy.com/login");
		driver.manage().window().maximize();
	}

	
	@Test
	void login() {
		//creating the object for login class
		LoginPage2 lp=new LoginPage2(driver);
		
		lp.setUsername("vikash.kumar");  // Enter Actual username
		lp.setPassword("vikash.kumar1");  // Enter Actual password
		lp.clickLogin();
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.urlToBe("https://www.app.aisensy.com/projects/64e60ac3b582c60e76a1ad78/dashboard"));

		Assert.assertEquals(driver.getCurrentUrl(), "https://www.app.aisensy.com/projects/64e60ac3b582c60e76a1ad78/dashboard", "Not redirected to the expected dashboard.");
	}
	
	@Test(dependsOnMethods = "login")
	void contactAutomation() throws InterruptedException {
		ContactPage cp=new ContactPage(driver);
		
		String uniqueName=generateUniqueCampaignName();
		String uniqueNum=generateUniqueNum();
		
		
		
		
		Thread.sleep(2000);
		cp.clickOnContact();
		
		cp.clickOnSearchbox();
		
		cp.clickOnAddContact();
		
		cp.setUserName(uniqueName);
		
		cp.setWhatsappNumber(uniqueNum);
		
		Thread.sleep(2000);
		cp.clickOnAddContactBtn();
		
		
		//import contacts
		
		cp.clickOnImport();
		
		cp.clickOnImportContact();
		
		cp.clickOnUploadFile();
		
		cp.mapName();
		
		cp.mapNumber();
		
		cp.clickOnImportBtn();
		
		cp.verifySucessMsg();
		
		//import and broadcast 
		cp.clickOnImport();
		
		cp.clickOnImportAndBroadcastBtn();
		
		cp.setCampaignMsg(uniqueName);
		
		cp.clickOnBtnNext();
		
		cp.uploadFile();
		
		cp.mapName1();
		
		cp.mapNumber1();
		
		cp.clickOnBtnNext();
		
		cp.searchTemp("mark_test");
		
		//re use
		cp.clickOnBtnNext();
		
		cp.clickOnSkip();
		
		cp.clickOnSendNow();
		
		cp.verifySucessMsgImportBroadcast();
		
		
		//actions - export
		cp.clickOnContact();
		
		cp.clickOnBtnActions();
		
		cp.clickOnBtnExport();
		
		Thread.sleep(2000);
		cp.clickOnBtnExportFinal();
		
		//cp.clickOnBtnCancleFinal();
		
		//import history
		cp.clickOnContact();
		
		cp.clickOnBtnActions();
		
		cp.clickOnBtnImportHistory();
		
		cp.clickOnBtnCloseImportHistory();
		
	}
	
	@Test(dependsOnMethods = "contactAutomation")
	public void filter() {
		ContactPage cp=new ContactPage(driver);
		
		cp.clickOnContact();
		
		cp.clickOnBtnFilter();
		
	}
//	
//	@Test(dependsOnMethods = "contactAutomation")
//	public void addContact() throws InterruptedException {
//		ContactPage cp=new ContactPage(driver);
//
//		String uniqueName=generateUniqueCampaignName();
//		String uniqueNum=generateUniqueNum();
//		
//		
//		cp.clickOnAddContact();
//		
//		cp.setUserName(uniqueName);
//		
//		cp.setWhatsappNumber(uniqueNum);
//		
//		Thread.sleep(2000);
//		cp.clickOnAddContactBtn();
//		
//	}
//	
//	@Test(dependsOnMethods = "contactAutomation")
//	public void importContact() {
//		
//		ContactPage cp=new ContactPage(driver);
//		
//		cp.clickOnImport();
//		
//		cp.clickOnImportContact();
//		
//		cp.clickOnUploadFile();
//		
//		cp.mapName();
//		
//		cp.mapNumber();
//		
//		cp.clickOnImportBtn();
//		
//		cp.verifySucessMsg();
//		
//		//import and broadcast 
//		cp.clickOnImport();
//		
//		cp.clickOnImportAndBroadcastBtn();
//		
//	}
}
